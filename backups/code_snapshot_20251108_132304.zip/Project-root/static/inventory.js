"use strict";

const Inventory = {
  state: {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    isLoading: false,
    selectedItems: new Set(),
    allItems: [],
    allVariants: [],
  },
  elements: {},

  init() {
    if (!document.getElementById("inventory-table-body")) return;

    this.cacheDOMElements();
    this.bindEventListeners();
    this.fetchItems();
    this.setupSearchFunctionality();
  },

  cacheDOMElements() {
    const ids = [
      "inventory-table-body",
      "add-item-btn",
      "inventory-search",
      "low-stock-filter",
      "item-form",
      "variants-list-container",
      "add-variant-btn",
      "export-csv-btn",
      "import-data-btn",
    ];
    ids.forEach((id) => {
      const camelCaseId = id.replace(/-(\w)/g, (_, c) => c.toUpperCase());
      this.elements[camelCaseId] = document.getElementById(id);
    });
    this.elements.clearSearchBtn = document.querySelector(".clear-search-btn");
  },

  bindEventListeners() {
    this.elements.addItemBtn?.addEventListener("click", () => (window.location.href = "/add_item"));
    this.elements.exportCsvBtn?.addEventListener("click", () => this.exportInventoryToCSV());
    document.getElementById("low-stock-report-btn")?.addEventListener("click", () => this.showLowStockReport());
    document.getElementById("import-data-btn")?.addEventListener("click", () => this.openImportModal());
    document.getElementById("receive-stock-btn")?.addEventListener("click", () => this.openReceiveStockModal());
    document.getElementById("generate-po-btn")?.addEventListener("click", () => this.openPOModal());
    document.getElementById("print-low-stock-report-btn")?.addEventListener("click", () => this.printLowStockReport());
    document.getElementById("fetch-po-btn")?.addEventListener("click", () => this.fetchPODetails());
    document.getElementById("add-receive-item-btn")?.addEventListener("click", () => this.addReceiveItemRow());
    document.getElementById("add-po-item-btn")?.addEventListener("click", () => this.openVariantSearchModal());
    document.getElementById("add-selected-variants-btn")?.addEventListener("click", () => this.addSelectedVariantsToPO());
    document.getElementById("select-all-variants")?.addEventListener("change", (e) => this.toggleSelectAllVariants(e.target.checked));
    document.getElementById("receive-tax-percentage")?.addEventListener("input", () => this.updateReceiveTotals());
    document.getElementById("receive-discount-percentage")?.addEventListener("input", () => this.updateReceiveTotals());
    document.getElementById("receive-stock-form")?.addEventListener("submit", (e) => this.handleReceiveStockSubmit(e));
    document.getElementById("po-form")?.addEventListener("submit", (e) => this.handlePOFormSubmit(e));

    if (this.elements.inventorySearch) {
      const debouncedSearch = debounce((value) => this.handleSearch(value), 300);
      this.elements.inventorySearch.addEventListener("input", (e) => debouncedSearch(e.target.value));
      this.elements.inventorySearch.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          e.target.value = "";
          this.handleSearch("");
          e.target.blur();
        }
      });
    }

    this.elements.clearSearchBtn?.addEventListener("click", () => this.clearSearch());
    this.elements.lowStockFilter?.addEventListener("change", () => this.fetchItems());
    this.elements.inventoryTableBody?.addEventListener("click", (e) => {
        this.handleTableActions(e);
        this.handleVariantMatrixActions(e);
    });
    this.elements.inventoryTableBody?.addEventListener("change", (e) => {
      if (e.target.classList.contains("item-checkbox")) {
        this.updateBulkActionsVisibility();
      }
    });

    const selectAllCheckbox = document.getElementById("select-all-items");
    selectAllCheckbox?.addEventListener("change", (e) => this.toggleSelectAll(e.target.checked));
    document.getElementById("bulk-delete-btn")?.addEventListener("click", () => this.handleBulkDelete());

    this.elements.itemForm?.addEventListener("submit", (e) => this.handleItemFormSubmit(e));
    this.elements.addVariantBtn?.addEventListener("click", () => this.addVariantRow());
    this.elements.variantsListContainer?.addEventListener("click", (e) => {
      if (e.target.closest(".remove-variant-btn")) {
        e.target.closest("tr")?.remove();
        this.updateVariantPlaceholder();
      }
    });

    window.addEventListener("scroll", () => this.handleScroll());
  },

  setupSearchFunctionality() {
    if (this.elements.inventorySearch && this.elements.clearSearchBtn) {
      const toggleClearButton = () => {
        this.elements.clearSearchBtn.style.display = this.elements.inventorySearch.value ? "block" : "none";
      };
      this.elements.inventorySearch.addEventListener("input", toggleClearButton);
      toggleClearButton();
    }
  },

  /**
   * Fetches inventory items from the backend with pagination and filters
   * Handles loading states and error recovery
   */
  async fetchItems() {
    const lowStockOnly = this.elements.lowStockFilter?.checked || false;
    const searchTerm = this.elements.inventorySearch?.value || "";
    const url = new URL(`${App.config.apiBase}/items`, window.location.origin);
    url.searchParams.append("page", this.state.currentPage);
    url.searchParams.append("per_page", App.config.pagination.per_page);
    if (lowStockOnly) url.searchParams.append("low_stock", "true");
    if (searchTerm) url.searchParams.append("search", searchTerm);

    this.state.isLoading = true;

    try {
      const data = await App.fetchJson(url.toString());
      if (data?.items) {
        this.state.allItems = this.state.currentPage === 1 ? data.items : [...this.state.allItems, ...data.items];
        this.state.totalPages = data.total_pages || 1;
        this.state.totalItems = data.total_items || 0;
        this.renderItemsList(data.items, this.state.currentPage > 1);
        this.updateResultCount();
      } else {
        // Handle empty response or error
        if (this.state.currentPage === 1) {
          this.renderItemsList([], false);
        }
        App.showNotification('Failed to load inventory items. Please try again.', 'error');
      }
    } catch (error) {
      console.error('Error fetching items:', error);
      App.showNotification('Network error loading inventory. Please check your connection.', 'error');
      if (this.state.currentPage === 1) {
        this.renderItemsList([], false);
      }
    } finally {
      this.state.isLoading = false;
    }
  },

  renderItemsList(items, append = false) {
    if (!this.elements.inventoryTableBody) return;

    this.elements.inventoryTableBody.querySelector(".loading-row")?.remove();

    if (!append && items.length === 0) {
      const message = this.state.totalItems > 0 ? "No items match your search." : 'No items found. Click "Add New Item" to get started!';
      this.elements.inventoryTableBody.innerHTML = `<tr><td colspan="10" class="text-center p-8">${message}</td></tr>`;
      return;
    }

    const itemsHtml = items.map((item) => this.createItemRowHtml(item)).join("");
    if (append) {
      this.elements.inventoryTableBody.insertAdjacentHTML("beforeend", itemsHtml);
    } else {
      this.elements.inventoryTableBody.innerHTML = itemsHtml;
    }
  },

  createItemRowHtml(item) {
    const isChecked = this.state.selectedItems.has(item.id.toString());
    const statusClass = item.has_low_stock_variants ? "low-stock" : "in-stock";
    const statusText = item.has_low_stock_variants ? "Low Stock" : "In Stock";
    return `
      <tr class="item-row" data-item-id="${item.id}" data-item-name="${App.escapeHtml(item.name)}" data-item-description="${App.escapeHtml(item.description || "")}">
        <td><input type="checkbox" class="item-checkbox" data-item-id="${item.id}" ${isChecked ? "checked" : ""}></td>
        <td><button class="expand-btn" title="View Variants" aria-expanded="false"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9,18 15,12 9,6"></polyline></svg></button></td>
        <td><img src="/static/${item.image_path || "uploads/placeholder.png"}" alt="${App.escapeHtml(item.name)}" class="item-image-thumbnail"></td>
        <td data-label="Item Name" class="item-name-cell"><span title="${App.escapeHtml(item.description || "No description")}">${App.escapeHtml(item.name)}</span></td>
        <td data-label="Model">${App.escapeHtml(item.model || "--")}</td>
        <td data-label="Variation">${App.escapeHtml(item.variation || "--")}</td>
        <td data-label="Variants">${item.variant_count}</td>
        <td data-label="Total Stock" class="total-stock-cell">${item.total_stock}</td>
        <td data-label="Status" class="status-col"><span class="status-badge ${statusClass}">${statusText}</span></td>
        <td data-label="Actions" class="actions-cell">
          <button class="button create edit-item" title="Edit Item">Edit</button>
          <button class="button cancel delete-item" title="Delete Item">Delete</button>
        </td>
      </tr>
      <tr class="variant-details-row" style="display: none;"><td colspan="10" class="variant-details-container"></td></tr>
    `;
  },

  updateResultCount() {
    const resultCountEl = document.getElementById("search-result-count");
    if (resultCountEl) {
      resultCountEl.textContent = `Showing ${this.state.allItems.length} of ${this.state.totalItems} items`;
    }
  },

  handleScroll() {
    if (this.state.isLoading || this.state.currentPage >= this.state.totalPages) return;
    const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
    if (scrollTop + clientHeight >= scrollHeight - 100) {
      this.state.currentPage++;
      this.fetchItems();
    }
  },

  handleSearch(searchTerm) {
    this.state.currentPage = 1;
    this.elements.inventoryTableBody.innerHTML = ""; // Clear existing items
    this.fetchItems();
  },

  clearSearch() {
    this.elements.inventorySearch.value = "";
    this.handleSearch("");
    this.elements.inventorySearch.focus();
  },

  /**
   * Handles click actions on item table rows (expand, edit, delete)
   * @param {Event} e - Click event
   */
  async handleTableActions(e) {
    const button = e.target.closest("button");
    if (!button) return;

    const row = button.closest(".item-row");
    if (!row) return;

    // Fixed: Use 'row' instead of undefined 'itemRow'
    const itemId = row.dataset.itemId;
    const itemName = row.dataset.itemName;

    if (button.classList.contains("expand-btn")) {
      await this.toggleVariantDetails(row, button, itemId);
    } else if (button.classList.contains("edit-item")) {
      window.location.href = `/edit_item/${itemId}`;
    } else if (button.classList.contains("delete-item")) {
      this.deleteItem(itemId, itemName);
    }
  },

  async handleVariantMatrixActions(e) {
    const button = e.target.closest("button");
    if (!button) return;

    const variantRow = button.closest("tr[data-variant-id]");
    if (!variantRow) return; // Exit if not a variant action

    const variantId = variantRow.dataset.variantId;

    if (button.classList.contains("update-variant")) {
      const stockInput = variantRow.querySelector(".stock-input");
      const thresholdInput = variantRow.querySelector(".threshold-input");
      await this.handleVariantUpdate(variantId, stockInput.value, thresholdInput.value);
    } else if (button.classList.contains("delete-variant")) {
      await this.handleVariantDelete(variantId, variantRow);
    }
  },

  /**
   * Updates variant stock and threshold values
   * Calls both endpoints in parallel for efficiency
   * @param {string|number} variantId - The variant ID
   * @param {string|number} stock - The new stock value
   * @param {string|number} threshold - The new threshold value
   */
  async handleVariantUpdate(variantId, stock, threshold) {
    // Validate inputs
    const stockValue = parseInt(stock, 10);
    const thresholdValue = parseInt(threshold, 10);

    if (isNaN(stockValue) || stockValue < 0) {
      App.showNotification("Invalid stock value. Must be a positive number.", "error");
      return;
    }

    if (isNaN(thresholdValue) || thresholdValue < 0) {
      App.showNotification("Invalid threshold value. Must be a positive number.", "error");
      return;
    }

    try {
      // Call both endpoints in parallel for better performance
      const stockUpdatePromise = App.fetchJson(`${App.config.apiBase}/variants/${variantId}/stock`, {
        method: "PUT",
        body: JSON.stringify({ stock: stockValue }),
      });
      const thresholdUpdatePromise = App.fetchJson(`${App.config.apiBase}/variants/${variantId}/threshold`, {
        method: "PUT",
        body: JSON.stringify({ threshold: thresholdValue }),
      });

      const [stockResult, thresholdResult] = await Promise.all([stockUpdatePromise, thresholdUpdatePromise]);

      if (stockResult && thresholdResult) {
        App.showNotification("Variant updated successfully.", "success");

        // [BUG FIX] Update the total stock in the parent item row without full page refresh
        // The backend now returns new_total_stock and we need to find the correct item row
        if (stockResult.new_total_stock !== undefined) {
          // Find the item row by locating the parent of the variant details container
          const variantRow = document.querySelector(`tr[data-variant-id="${variantId}"]`);
          if (variantRow) {
            // Navigate up to find the item row (variant details are in a nested table)
            const detailsContainer = variantRow.closest('.variant-details-container');
            if (detailsContainer) {
              const detailsRow = detailsContainer.closest('tr.variant-details-row');
              const itemRow = detailsRow ? detailsRow.previousElementSibling : null;
              if (itemRow && itemRow.classList.contains('item-row')) {
                const totalStockCell = itemRow.querySelector('.total-stock-cell');
                if (totalStockCell) {
                  totalStockCell.textContent = stockResult.new_total_stock;
                }
                // [BUG FIX] Also update low stock status badge if returned
                if (stockResult.item_has_low_stock !== undefined) {
                  const statusBadge = itemRow.querySelector('.status-badge');
                  if (statusBadge) {
                    statusBadge.className = stockResult.item_has_low_stock ? 'status-badge low-stock' : 'status-badge in-stock';
                    statusBadge.textContent = stockResult.item_has_low_stock ? 'Low Stock' : 'In Stock';
                  }
                }
              }
            }
          }
        }
        
        // [BUG FIX] Update the variant row's stock/threshold display immediately
        const variantRowToUpdate = document.querySelector(`tr[data-variant-id="${variantId}"]`);
        if (variantRowToUpdate && stockResult.updated_variant) {
          const stockInputEl = variantRowToUpdate.querySelector('.stock-input');
          const thresholdInputEl = variantRowToUpdate.querySelector('.threshold-input');
          if (stockInputEl) stockInputEl.value = stockResult.updated_variant.stock;
          if (thresholdInputEl) thresholdInputEl.value = stockResult.updated_variant.threshold;
        }
      } else {
        App.showNotification("Failed to update variant. Please try again.", "error");
      }
    } catch (error) {
      console.error('Error updating variant:', error);
      App.showNotification("Network error updating variant.", "error");
    }
  },

  async handleVariantDelete(variantId, variantRow) {
    if (!confirm("Are you sure you want to delete this variant? This action cannot be undone.")) {
      return;
    }

    const result = await App.fetchJson(`${App.config.apiBase}/variants/${variantId}`, {
      method: "DELETE",
    });

    if (result) {
      variantRow.remove();
      App.showNotification("Variant deleted successfully.", "success");
    } else {
      App.showNotification("Failed to delete variant. It might be in use.", "error");
    }
  },

  /**
   * Toggles the visibility of variant details for an item
   * Fetches and displays variant matrix on first expand
   * @param {HTMLElement} itemRow - The item row element
   * @param {HTMLElement} expandBtn - The expand button
   * @param {string|number} itemId - The item ID
   */
  async toggleVariantDetails(itemRow, expandBtn, itemId) {
    const detailsRow = itemRow.nextElementSibling;
    const isVisible = detailsRow.style.display !== "none";

    // Collapse if already visible
    if (isVisible) {
      detailsRow.style.display = "none";
      expandBtn.classList.remove("expanded");
      expandBtn.setAttribute("aria-expanded", "false");
      return;
    }

    // Show loading state
    const container = detailsRow.querySelector(".variant-details-container");
    container.innerHTML = `<div class="p-4 text-center loading-spinner">
      <div class="spinner"></div>
      <span>Loading variants...</span>
    </div>`;
    detailsRow.style.display = "table-row";
    expandBtn.classList.add("expanded");
    expandBtn.setAttribute("aria-expanded", "true");

    // Fetch variants with error handling
    try {
      const variants = await App.fetchJson(`${App.config.apiBase}/items/${itemId}/variants`);

      requestAnimationFrame(() => {
        container.innerHTML = "";

        // Display item description if available
        if (itemRow.dataset.itemDescription) {
          container.innerHTML += `<div class="item-description-detail"><strong>Description:</strong> ${App.escapeHtml(itemRow.dataset.itemDescription)}</div>`;
        }

        // Render variants or show empty state
        if (variants && variants.length > 0) {
          this.renderVariantMatrix(container, variants);
        } else if (variants) {
          container.innerHTML += `<p class="p-4 text-center">No variants found for this item.</p>`;
        } else {
          // Error case
          container.innerHTML += `<p class="p-4 text-center" style="color: var(--danger-color);">Failed to load variants. Please try again.</p>`;
        }
      });
    } catch (error) {
      console.error('Error loading variants:', error);
      container.innerHTML = `<p class="p-4 text-center" style="color: var(--danger-color);">Network error loading variants.</p>`;
    }
  },

  renderVariantMatrix(container, variants) {
    const table = document.createElement("table");
    table.className = "variant-matrix-table";
    table.innerHTML = `
      <thead>
        <tr>
          <th>Color</th>
          <th>Size</th>
          <th>Stock</th>
          <th>Threshold</th>
          <th>Unit</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${variants
          .map(
            (v) => `
          <tr data-variant-id="${v.id}">
            <td>${App.escapeHtml(v.color.name)}</td>
            <td>${App.escapeHtml(v.size.name)}</td>
            <td><input type="number" class="stock-input" value="${
              v.opening_stock
            }" min="0"></td>
            <td><input type="number" class="threshold-input" value="${
              v.threshold
            }" min="0"></td>
            <td>${App.escapeHtml(v.unit || "N/A")}</td>
            <td class="actions-cell">
              <button class="button-icon update-variant" title="Save Changes"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg></button>
              <button class="button-icon delete-variant" title="Delete Variant"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
            </td>
          </tr>
        `
          )
          .join("")}
      </tbody>
    `;
    container.appendChild(table);
  },

  updateBulkActionsVisibility() {
    const bulkActionsBar = document.getElementById("bulk-actions-bar");
    const selectedCount = document.getElementById("selected-item-count");
    if (!bulkActionsBar || !selectedCount) return;

    const count = this.state.selectedItems.size;
    if (count > 0) {
      bulkActionsBar.classList.add("visible");
      selectedCount.textContent = `${count} item${count > 1 ? 's' : ''} selected`;
    } else {
      bulkActionsBar.classList.remove("visible");
    }
  },

  toggleSelectAll(isChecked) {
    const checkboxes = this.elements.inventoryTableBody.querySelectorAll(".item-checkbox");
    checkboxes.forEach(checkbox => {
      checkbox.checked = isChecked;
      const itemId = checkbox.dataset.itemId;
      if (isChecked) {
        this.state.selectedItems.add(itemId);
      } else {
        this.state.selectedItems.delete(itemId);
      }
    });
    this.updateBulkActionsVisibility();
  },

  async handleBulkDelete() {
    const count = this.state.selectedItems.size;
    if (count === 0) return;

    if (!confirm(`Are you sure you want to delete ${count} selected item(s)? This action cannot be undone.`)) {
      return;
    }

    const itemIds = Array.from(this.state.selectedItems);
    const result = await App.fetchJson(`${App.config.apiBase}/items/bulk-delete`, {
      method: "POST",
      body: JSON.stringify({ item_ids: itemIds }),
    });

    if (result) {
      itemIds.forEach(id => {
        const row = document.querySelector(`.item-row[data-item-id="${id}"]`);
        if (row) {
          row.nextElementSibling?.remove();
          row.remove();
        }
      });
      this.state.selectedItems.clear();
      this.updateBulkActionsVisibility();
      App.showNotification(result.message || "Items deleted successfully.", "success");
    } else {
      App.showNotification("Failed to delete some items. They may be in use.", "error");
    }
  },

  async handleItemFormSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const itemId = form.dataset.itemId;
    const url = itemId ? `${App.config.apiBase}/items/${itemId}` : `${App.config.apiBase}/items`;
    const method = itemId ? "PUT" : "POST";

    const formData = new FormData(form);
    const variants = [];
    this.elements.variantsListContainer.querySelectorAll("tr").forEach(row => {
        variants.push({
            id: row.dataset.variantId || null,
            color: row.querySelector('input[name="color"]').value,
            size: row.querySelector('input[name="size"]').value,
            opening_stock: row.querySelector('input[name="opening_stock"]').value || 0,
            threshold: row.querySelector('input[name="threshold"]').value || 5,
            unit: row.querySelector('input[name="unit"]').value || 'Pcs',
        });
    });

    formData.append("variants", JSON.stringify(variants));

    // For PUT requests, FormData doesn't work as expected with Flask/Werkzeug for file uploads + other data.
    // A common workaround is to use POST and add a method override field, but the backend is already set up for PUT.
    // The backend handles multipart form data correctly on PUT, so we can proceed.

    const response = await App.fetchJson(url, {
      method: method,
      body: formData,
      headers: {
        // Let the browser set the Content-Type for FormData
      },
    });

    if (response) {
      App.showNotification(`Item ${itemId ? 'updated' : 'added'} successfully!`, "success");
      window.location.href = "/inventory";
    } else {
      App.showNotification("Failed to save item.", "error");
    }
  },
  addVariantRow(variant = {}) {
    const newRow = document.createElement("tr");
    if(variant.id) {
        newRow.dataset.variantId = variant.id;
    }
    newRow.innerHTML = `
      <td><input type="text" name="color" class="form-control" value="${App.escapeHtml(variant.color?.name || '')}" required></td>
      <td><input type="text" name="size" class="form-control" value="${App.escapeHtml(variant.size?.name || '')}" required></td>
      <td><input type="number" name="opening_stock" class="form-control" value="${variant.opening_stock || 0}" min="0"></td>
      <td><input type="number" name="threshold" class="form-control" value="${variant.threshold || 5}" min="0"></td>
      <td><input type="text" name="unit" class="form-control" value="${App.escapeHtml(variant.unit || 'Pcs')}"></td>
      <td><button type="button" class="button cancel small remove-variant-btn">Remove</button></td>
    `;
    this.elements.variantsListContainer.appendChild(newRow);
    this.updateVariantPlaceholder();
  },
  updateVariantPlaceholder() {
    const placeholder = document.getElementById("variants-placeholder");
    if (placeholder) {
      placeholder.style.display = this.elements.variantsListContainer.children.length > 0 ? "none" : "table-row";
    }
  },
  async deleteItem(itemId, itemName) {
    if (!confirm(`Are you sure you want to delete "${itemName}"? This will also delete all its variants and cannot be undone.`)) {
      return;
    }

    const result = await App.fetchJson(`${App.config.apiBase}/items/${itemId}`, {
      method: "DELETE",
    });

    if (result) {
      const row = document.querySelector(`.item-row[data-item-id="${itemId}"]`);
      if (row) {
        row.nextElementSibling.remove(); // Remove variant details row
        row.remove(); // Remove item row
      }
      App.showNotification("Item deleted successfully.", "success");
    } else {
      App.showNotification("Failed to delete item. It might be associated with purchase orders or stock entries.", "error");
    }
  },

  async showLowStockReport() {
    const reportModal = document.getElementById("low-stock-report-modal");
    const reportBody = document.getElementById("low-stock-report-body");
    if (!reportModal || !reportBody) return;

    reportBody.innerHTML = '<tr><td colspan="7" class="text-center">Loading report...</td></tr>';
    reportModal.classList.add("is-open");

    const data = await App.fetchJson(`${App.config.apiBase}/low-stock-report`);
    if (data) {
      if (data.length === 0) {
        reportBody.innerHTML = '<tr><td colspan="7" class="text-center">No items are low on stock.</td></tr>';
        return;
      }
      reportBody.innerHTML = data.map(item => `
        <tr>
          <td>${App.escapeHtml(item.item_name)}</td>
          <td>${App.escapeHtml(item.model_name || '--')}</td>
          <td>${App.escapeHtml(item.variation_name || '--')}</td>
          <td>${App.escapeHtml(item.color_name)}</td>
          <td>${App.escapeHtml(item.size_name)}</td>
          <td>${item.opening_stock}</td>
          <td>${item.threshold}</td>
        </tr>
      `).join('');
    } else {
      reportBody.innerHTML = '<tr><td colspan="7" class="text-center">Failed to load report.</td></tr>';
    }
  },

  exportInventoryToCSV() {
    window.location.href = `${App.config.apiBase}/inventory/export/csv`;
  },

  /**
   * Opens the import data modal
   */
  openImportModal() {
    const modal = document.getElementById("import-modal");
    if (modal) {
      modal.classList.add("is-open");
      // Reset to step 1
      document.getElementById("import-step-1").style.display = "block";
      document.getElementById("import-step-2").style.display = "none";
      document.getElementById("import-next-btn").style.display = "inline-block";
      document.getElementById("import-commit-btn").style.display = "none";
      document.getElementById("import-back-btn").style.display = "none";
    }
  },

  /**
   * Opens the receive stock modal
   */
  openReceiveStockModal() {
    const modal = document.getElementById("receive-stock-modal");
    if (modal) {
      modal.classList.add("is-open");
      this.loadSuppliersForReceive();
      this.clearReceiveStockForm();
    }
  },

  /**
   * Opens the Purchase Order modal
   */
  openPOModal() {
    const modal = document.getElementById("po-modal");
    if (modal) {
      modal.classList.add("is-open");
      this.loadSuppliersForPO();
      this.clearPOForm();
    }
  },

  /**
   * Prints the low stock report
   */
  printLowStockReport() {
    const printContent = document.getElementById("low-stock-report-printable");
    if (!printContent) return;

    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Low Stock Report</title>');
    printWindow.document.write('<style>');
    printWindow.document.write('body { font-family: Arial, sans-serif; padding: 20px; }');
    printWindow.document.write('table { width: 100%; border-collapse: collapse; }');
    printWindow.document.write('th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }');
    printWindow.document.write('th { background-color: #f2f2f2; }');
    printWindow.document.write('h1 { text-align: center; }');
    printWindow.document.write('</style></head><body>');
    printWindow.document.write('<h1>Low Stock Report</h1>');
    printWindow.document.write(printContent.innerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
  },

  /**
   * Fetches PO details based on PO number
   */
  async fetchPODetails() {
    const poNumber = document.getElementById("receive-po-number")?.value.trim();
    if (!poNumber) {
      App.showNotification("Please enter a PO number", "error");
      return;
    }

    try {
      const data = await App.fetchJson(`${App.config.apiBase}/purchase-orders/by-number/${encodeURIComponent(poNumber)}`);
      if (data) {
        // Populate supplier
        const supplierSelect = document.getElementById("receive-supplier-select");
        if (supplierSelect && data.supplier_id) {
          supplierSelect.value = data.supplier_id;
        }

        // Clear existing items
        const itemsBody = document.getElementById("receive-items-body");
        if (itemsBody) {
          itemsBody.innerHTML = '';
        }

        // Add items from PO
        if (data.items && Array.isArray(data.items)) {
          data.items.forEach(item => {
            this.addReceiveItemRow(item);
          });
        }

        App.showNotification("PO details loaded successfully", "success");
      } else {
        App.showNotification("PO not found", "error");
      }
    } catch (error) {
      console.error("Error fetching PO:", error);
      App.showNotification("Failed to fetch PO details", "error");
    }
  },

  /**
   * Adds a row to the receive stock form
   */
  addReceiveItemRow(item = {}) {
    const tbody = document.getElementById("receive-items-body");
    if (!tbody) return;

    const row = document.createElement("tr");
    row.className = "receive-item-row";
    row.innerHTML = `
      <td>
        <select name="variant_id" class="variant-select" required>
          <option value="">Select Item/Variant...</option>
          ${this.state.allItems.map(v => `
            <option value="${v.id}" ${item.variant_id == v.id ? 'selected' : ''}>
              ${App.escapeHtml(v.name || v.full_name || '')}
            </option>
          `).join('')}
        </select>
      </td>
      <td><input type="number" name="quantity" placeholder="Qty" required min="1" value="${item.quantity || 1}"></td>
      <td><input type="number" name="cost_per_unit" placeholder="Cost" required min="0" step="0.01" value="${item.rate || item.cost_per_unit || 0}"></td>
      <td class="receive-item-total">₹${((item.quantity || 1) * (item.rate || item.cost_per_unit || 0)).toFixed(2)}</td>
      <td>
        <button type="button" class="button-icon remove-receive-item" title="Remove Item">&times;</button>
      </td>
    `;

    // Add event listeners for automatic calculation
    const qtyInput = row.querySelector('[name="quantity"]');
    const costInput = row.querySelector('[name="cost_per_unit"]');
    const totalCell = row.querySelector('.receive-item-total');

    const updateTotal = () => {
      const qty = parseFloat(qtyInput.value) || 0;
      const cost = parseFloat(costInput.value) || 0;
      const total = qty * cost;
      totalCell.textContent = `₹${total.toFixed(2)}`;
      this.updateReceiveTotals();
    };

    qtyInput.addEventListener('input', updateTotal);
    costInput.addEventListener('input', updateTotal);

    // Handle remove button
    row.querySelector('.remove-receive-item').addEventListener('click', () => {
      row.remove();
      this.updateReceiveTotals();
    });

    tbody.appendChild(row);
    this.updateReceiveTotals();
  },

  /**
   * Updates the totals in the receive stock form
   */
  updateReceiveTotals() {
    const rows = document.querySelectorAll('.receive-item-row');
    let subtotal = 0;

    rows.forEach(row => {
      const qty = parseFloat(row.querySelector('[name="quantity"]').value) || 0;
      const cost = parseFloat(row.querySelector('[name="cost_per_unit"]').value) || 0;
      subtotal += qty * cost;
    });

    const taxPercent = parseFloat(document.getElementById('receive-tax-percentage')?.value) || 0;
    const discountPercent = parseFloat(document.getElementById('receive-discount-percentage')?.value) || 0;

    const discountAmount = (subtotal * discountPercent) / 100;
    const taxableAmount = subtotal - discountAmount;
    const taxAmount = (taxableAmount * taxPercent) / 100;
    const grandTotal = taxableAmount + taxAmount;

    // Update display elements
    if (document.getElementById('receive-discount-amount')) {
      document.getElementById('receive-discount-amount').textContent = `₹${discountAmount.toFixed(2)}`;
    }
    if (document.getElementById('receive-total-amount')) {
      document.getElementById('receive-total-amount').textContent = `₹${subtotal.toFixed(2)}`;
    }
    if (document.getElementById('receive-grand-total')) {
      document.getElementById('receive-grand-total').textContent = `₹${grandTotal.toFixed(2)}`;
    }
  },

  /**
   * Opens the variant search modal for PO
   */
  openVariantSearchModal() {
    const modal = document.getElementById("variant-search-modal");
    if (modal) {
      modal.classList.add("is-open");
      this.loadAllVariantsForSearch();
    }
  },

  /**
   * Loads all variants for the search modal
   * [BUG FIX] Added proper error handling and null checks
   */
  async loadAllVariantsForSearch() {
    try {
      const data = await App.fetchJson(`${App.config.apiBase}/all-variants`);
      if (data && Array.isArray(data)) {
        this.state.allVariants = data;
        this.renderVariantSearchResults();
      } else {
        // [BUG FIX] Handle invalid response format
        this.state.allVariants = [];
        this.renderVariantSearchResults();
        console.warn('Invalid variant data format received from backend');
      }
    } catch (error) {
      console.error("Error loading variants:", error);
      this.state.allVariants = [];
      this.renderVariantSearchResults(); // Show empty results rather than breaking UI
      App.showNotification("Failed to load variants", "error");
    }
  },

  /**
   * Renders the variant search results
   * [BUG FIX] Updated field name mapping to match backend response format
   * Backend returns: {id, name} where name is the full concatenated string
   */
  renderVariantSearchResults() {
    const searchInput = document.getElementById("variant-search-input");
    const resultsBody = document.getElementById("variant-search-results");
    if (!resultsBody) return;

    const searchTerm = searchInput?.value.toLowerCase() || '';
    
    // [BUG FIX] Backend returns simple {id, name} format, parse it for display
    const filtered = this.state.allVariants?.filter(v =>
      (v.name || '').toLowerCase().includes(searchTerm)
    ) || [];

    resultsBody.innerHTML = filtered.map(v => {
      // [BUG FIX] Parse the full variant name to extract components
      // Format is typically: "ItemName - Color / Size"
      const displayName = v.name || 'Unknown Variant';
      
      return `
        <tr>
          <td><input type="checkbox" class="variant-checkbox" data-variant-id="${v.id}" data-variant-name="${App.escapeHtml(displayName)}"></td>
          <td colspan="5">${App.escapeHtml(displayName)}</td>
        </tr>
      `;
    }).join('');

    // Add search input listener if not already added
    if (searchInput && !searchInput.dataset.listenerAdded) {
      searchInput.addEventListener('input', () => this.renderVariantSearchResults());
      searchInput.dataset.listenerAdded = 'true';
    }
  },

  /**
   * Toggles select all variants checkbox
   */
  toggleSelectAllVariants(checked) {
    const checkboxes = document.querySelectorAll('#variant-search-results .variant-checkbox');
    checkboxes.forEach(cb => cb.checked = checked);
  },

  /**
   * Adds selected variants to PO
   */
  addSelectedVariantsToPO() {
    const selected = document.querySelectorAll('#variant-search-results .variant-checkbox:checked');
    const poItemsContainer = document.getElementById("po-items-container");

    if (!poItemsContainer) return;

    selected.forEach(cb => {
      const row = document.createElement('div');
      row.className = 'po-item-row';
      row.dataset.variantId = cb.dataset.variantId;
      row.innerHTML = `
        <span>${App.escapeHtml(cb.dataset.variantName)}</span>
        <input type="number" name="quantity" placeholder="Qty" required min="1" value="1">
        <input type="number" name="rate" placeholder="Rate" required min="0" step="0.01" value="0">
        <button type="button" class="button-icon remove-po-item">&times;</button>
      `;

      // Add remove listener
      row.querySelector('.remove-po-item').addEventListener('click', () => row.remove());

      poItemsContainer.appendChild(row);
    });

    // Close modal
    const modal = document.getElementById("variant-search-modal");
    if (modal) {
      modal.classList.remove("is-open");
    }

    App.showNotification(`Added ${selected.length} variant(s) to PO`, "success");
  },

  /**
   * Loads suppliers for the receive stock form
   */
  async loadSuppliersForReceive() {
    try {
      const data = await App.fetchJson(`${App.config.apiBase}/suppliers`);
      const select = document.getElementById("receive-supplier-select");
      if (select && data && Array.isArray(data)) {
        select.innerHTML = '<option value="">Select Supplier...</option>' +
          data.map(s => `<option value="${s.id}">${App.escapeHtml(s.firm_name)}</option>`).join('');
      }
    } catch (error) {
      console.error("Error loading suppliers:", error);
    }
  },

  /**
   * Loads suppliers for the PO form
   */
  async loadSuppliersForPO() {
    try {
      const data = await App.fetchJson(`${App.config.apiBase}/suppliers`);
      const container = document.getElementById("po-supplier-container");
      if (container && data && Array.isArray(data)) {
        container.innerHTML = `
          <div class="form-field">
            <label for="po-supplier-id">Supplier *</label>
            <select id="po-supplier-id" name="supplier_id" required>
              <option value="">Select Supplier...</option>
              ${data.map(s => `<option value="${s.id}">${App.escapeHtml(s.firm_name)}</option>`).join('')}
            </select>
          </div>
        `;
      }
    } catch (error) {
      console.error("Error loading suppliers:", error);
    }
  },

  /**
   * Clears the receive stock form
   */
  clearReceiveStockForm() {
    const form = document.getElementById("receive-stock-form");
    if (form) {
      form.reset();
    }
    const itemsBody = document.getElementById("receive-items-body");
    if (itemsBody) {
      itemsBody.innerHTML = '';
    }
    this.updateReceiveTotals();
  },

  /**
   * Clears the PO form
   */
  clearPOForm() {
    const form = document.getElementById("po-form");
    if (form) {
      form.reset();
    }
    const itemsContainer = document.getElementById("po-items-container");
    if (itemsContainer) {
      itemsContainer.innerHTML = '';
    }
  },

  /**
   * Handles receive stock form submission
   */
  async handleReceiveStockSubmit(e) {
    e.preventDefault();

    const supplierId = document.getElementById("receive-supplier-select")?.value;
    const billNumber = document.getElementById("receive-bill-number")?.value || '';
    const poNumber = document.getElementById("receive-po-number")?.value || '';

    if (!supplierId) {
      App.showNotification("Please select a supplier", "error");
      return;
    }

    const items = [];
    const itemRows = document.querySelectorAll('.receive-item-row');

    if (itemRows.length === 0) {
      App.showNotification("Please add at least one item", "error");
      return;
    }

    let hasError = false;
    itemRows.forEach(row => {
      const variantId = row.querySelector('[name="variant_id"]').value;
      const quantity = parseInt(row.querySelector('[name="quantity"]').value, 10);
      const costPerUnit = parseFloat(row.querySelector('[name="cost_per_unit"]').value);

      if (!variantId || isNaN(quantity) || quantity <= 0 || isNaN(costPerUnit) || costPerUnit < 0) {
        hasError = true;
        return;
      }

      items.push({
        variant_id: variantId,
        quantity: quantity,
        cost_per_unit: costPerUnit
      });
    });

    if (hasError) {
      App.showNotification("Please ensure all items have valid values", "error");
      return;
    }

    // [BUG FIX] Align field names with backend expectations
    // Backend expects 'cost' not 'cost_per_unit' for items array
    const receiptData = {
      supplier_id: parseInt(supplierId, 10),
      bill_number: billNumber,
      po_number: poNumber,
      items: items.map(item => ({
        variant_id: item.variant_id,
        quantity: item.quantity,
        cost: item.cost_per_unit  // Backend expects 'cost' field name
      })),
      tax_percentage: parseFloat(document.getElementById('receive-tax-percentage')?.value) || 0,
      discount_percentage: parseFloat(document.getElementById('receive-discount-percentage')?.value) || 0
    };

    try {
      const result = await App.fetchJson(`${App.config.apiBase}/stock-receipts`, {
        method: 'POST',
        body: JSON.stringify(receiptData)
      });

      if (result) {
        const modal = document.getElementById("receive-stock-modal");
        if (modal) {
          modal.classList.remove("is-open");
        }
        App.showNotification("Stock received and inventory updated successfully", "success");
        this.fetchItems(); // Refresh inventory list
      }
    } catch (error) {
      console.error('Error submitting stock receipt:', error);
      App.showNotification("Failed to submit stock receipt", "error");
    }
  },

  /**
   * Handles PO form submission
   */
  async handlePOFormSubmit(e) {
    e.preventDefault();

    const supplierId = document.getElementById("po-supplier-id")?.value;

    if (!supplierId) {
      App.showNotification("Please select a supplier", "error");
      return;
    }

    const items = [];
    const itemRows = document.querySelectorAll('.po-item-row');

    if (itemRows.length === 0) {
      App.showNotification("Please add at least one item to the purchase order", "error");
      return;
    }

    let hasError = false;
    itemRows.forEach(row => {
      const variantId = row.dataset.variantId;
      const quantity = parseInt(row.querySelector('[name="quantity"]').value, 10);
      const rate = parseFloat(row.querySelector('[name="rate"]').value);

      if (!variantId || isNaN(quantity) || quantity <= 0 || isNaN(rate) || rate < 0) {
        hasError = true;
        return;
      }

      items.push({
        variant_id: variantId,
        quantity: quantity,
        rate: rate
      });
    });

    if (hasError) {
      App.showNotification("Please ensure all items have valid quantity and rate values", "error");
      return;
    }

    const poData = {
      supplier_id: parseInt(supplierId, 10),
      items: items,
      notes: '',
      status: 'Draft'
    };

    try {
      const result = await App.fetchJson(`${App.config.apiBase}/purchase-orders`, {
        method: 'POST',
        body: JSON.stringify(poData)
      });

      if (result) {
        const modal = document.getElementById("po-modal");
        if (modal) {
          modal.classList.remove("is-open");
        }
        App.showNotification("Purchase order created successfully", "success");
      }
    } catch (error) {
      console.error('Error creating purchase order:', error);
      App.showNotification("Failed to create purchase order", "error");
    }
  },
};

// Ensure App is loaded before initializing Inventory
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    if (typeof App !== 'undefined') {
      Inventory.init();
    } else {
      console.error('App object not found. Make sure main.js is loaded first.');
    }
  });
} else {
  // DOM already loaded
  if (typeof App !== 'undefined') {
    Inventory.init();
  } else {
    console.error('App object not found. Make sure main.js is loaded first.');
  }
}
