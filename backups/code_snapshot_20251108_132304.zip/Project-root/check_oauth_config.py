"""
DEPRECATED: This OAuth diagnostic script is no longer used.

Reason: Google OAuth logic has been rewritten and simplified in `auth/routes.py`.
Please remove this file from the repository if not needed.
"""

if __name__ == "__main__":
    print("This script is deprecated and no longer in use.")
