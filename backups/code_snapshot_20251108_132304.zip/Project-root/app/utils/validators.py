"""Validation utilities."""
