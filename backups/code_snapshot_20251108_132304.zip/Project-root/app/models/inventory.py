"""Inventory model."""
